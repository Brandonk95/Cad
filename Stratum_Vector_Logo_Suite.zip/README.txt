STRATUM VECTOR LOGO SUITE

All SVG files contain genuine vector path geometry, including outlined wordmark lettering. No raster image embeds, external fonts, or filters. Transparent variants have no background element.

Brand colors: Filament Teal #1FB5A8, Build Plate Black #16181C, Raft White #F4F5F7.

Open SVG files in Figma, Illustrator, Inkscape, or a browser. Shapes can be resized without pixelation.
